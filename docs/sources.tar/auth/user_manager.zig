const std = @import("std");
const Allocator = std.mem.Allocator;
const auth = @import("auth");
const rls = @import("rls");
const storage = @import("storage/interface");

// User Management CLI and API
pub const UserManager = struct {
    allocator: Allocator,
    security_manager: *auth.SecurityManager,
    rls_engine: *rls.RLSEngine,
    storage_backend: storage.Interface,
    
    const Self = @This();
    
    pub fn init(
        allocator: Allocator,
        security_manager: *auth.SecurityManager,
        rls_engine: *rls.RLSEngine,
        storage_backend: storage.Interface,
    ) !Self {
        return Self{
            .allocator = allocator,
            .security_manager = security_manager,
            .rls_engine = rls_engine,
            .storage_backend = storage_backend,
        };
    }
    
    pub fn deinit(self: *Self) void {
        _ = self;
    }
    
    // User CRUD Operations
    pub const CreateUserRequest = struct {
        username: []const u8,
        email: []const u8,
        password: []const u8,
        roles: ?[]const []const u8 = null,
        attributes: ?std.json.Value = null,
        metadata: ?std.json.Value = null,
    };
    
    pub const CreateUserResponse = struct {
        user_id: auth.UserId,
        username: []const u8,
        email: []const u8,
        created_at: i64,
        roles: []const []const u8,
    };
    
    pub fn createUser(self: *Self, request: CreateUserRequest) !CreateUserResponse {
        // Create the user
        const user = try self.security_manager.createUser(
            request.username,
            request.email,
            request.password,
        );
        
        // Assign roles if specified
        if (request.roles) |roles| {
            for (roles) |role_name| {
                // Find role by name
                var role_id: ?auth.RoleId = null;
                var it = self.security_manager.roles.iterator();
                while (it.next()) |entry| {
                    if (std.mem.eql(u8, entry.value_ptr.name, role_name)) {
                        role_id = entry.key_ptr.*;
                        break;
                    }
                }
                
                if (role_id) |id| {
                    try self.security_manager.assignRole(user.id, id);
                }
            }
        }
        
        // Set attributes if provided
        if (request.attributes) |attrs| {
            if (attrs == .object) {
                var attr_it = attrs.object.iterator();
                while (attr_it.next()) |entry| {
                    if (entry.value_ptr.* == .string) {
                        try user.attributes.put(
                            try self.allocator.dupe(u8, entry.key_ptr.*),
                            try self.allocator.dupe(u8, entry.value_ptr.string),
                        );
                    }
                }
            }
        }
        
        // Set metadata if provided
        if (request.metadata) |meta| {
            user.metadata = meta;
        }
        
        // Persist to storage
        try self.persistUser(user);
        
        // Build response
        var response_roles = std.ArrayList([]const u8).init(self.allocator);
        if (self.security_manager.rbac.user_roles.get(user.id)) |user_roles| {
            for (user_roles.items) |role_id| {
                if (self.security_manager.roles.get(role_id)) |role| {
                    try response_roles.append(role.name);
                }
            }
        }
        
        return CreateUserResponse{
            .user_id = user.id,
            .username = user.username,
            .email = user.email,
            .created_at = user.created_at,
            .roles = try response_roles.toOwnedSlice(),
        };
    }
    
    pub const UpdateUserRequest = struct {
        user_id: auth.UserId,
        email: ?[]const u8 = null,
        password: ?[]const u8 = null,
        is_active: ?bool = null,
        mfa_enabled: ?bool = null,
        attributes: ?std.json.Value = null,
        metadata: ?std.json.Value = null,
    };
    
    pub fn updateUser(self: *Self, request: UpdateUserRequest) !void {
        const user = self.security_manager.users.getPtr(request.user_id) orelse
            return error.UserNotFound;
        
        // Update fields
        if (request.email) |email| {
            user.email = try self.allocator.dupe(u8, email);
        }
        
        if (request.password) |password| {
            try self.security_manager.validatePassword(password);
            user.password_hash = try self.security_manager.hashPassword(password);
        }
        
        if (request.is_active) |is_active| {
            user.is_active = is_active;
        }
        
        if (request.mfa_enabled) |mfa_enabled| {
            user.mfa_enabled = mfa_enabled;
            if (mfa_enabled and user.mfa_secret == null) {
                // Generate MFA secret
                user.mfa_secret = try self.generateMFASecret();
            }
        }
        
        if (request.attributes) |attrs| {
            user.attributes.clearRetainingCapacity();
            if (attrs == .object) {
                var it = attrs.object.iterator();
                while (it.next()) |entry| {
                    if (entry.value_ptr.* == .string) {
                        try user.attributes.put(
                            try self.allocator.dupe(u8, entry.key_ptr.*),
                            try self.allocator.dupe(u8, entry.value_ptr.string),
                        );
                    }
                }
            }
        }
        
        if (request.metadata) |meta| {
            user.metadata = meta;
        }
        
        user.updated_at = std.time.milliTimestamp();
        
        // Persist changes
        try self.persistUser(user.*);
    }
    
    pub fn deleteUser(self: *Self, user_id: auth.UserId) !void {
        // Remove user roles
        if (self.security_manager.rbac.user_roles.get(user_id)) |roles| {
            for (roles.items) |role_id| {
                try self.security_manager.revokeRole(user_id, role_id);
            }
        }
        
        // Remove from storage
        try self.removeUserFromStorage(user_id);
        
        // Remove from memory
        _ = self.security_manager.users.remove(user_id);
    }
    
    pub fn getUser(self: *Self, user_id: auth.UserId) !auth.User {
        return self.security_manager.users.get(user_id) orelse
            error.UserNotFound;
    }
    
    pub fn listUsers(self: *Self, filter: ?UserFilter) ![]auth.User {
        var users = std.ArrayList(auth.User).init(self.allocator);
        
        var it = self.security_manager.users.iterator();
        while (it.next()) |entry| {
            if (filter) |f| {
                if (!self.matchesFilter(entry.value_ptr.*, f)) continue;
            }
            try users.append(entry.value_ptr.*);
        }
        
        return try users.toOwnedSlice();
    }
    
    pub const UserFilter = struct {
        is_active: ?bool = null,
        is_superuser: ?bool = null,
        has_mfa: ?bool = null,
        role_name: ?[]const u8 = null,
        created_after: ?i64 = null,
        created_before: ?i64 = null,
    };
    
    fn matchesFilter(self: *Self, user: auth.User, filter: UserFilter) bool {
        if (filter.is_active) |is_active| {
            if (user.is_active != is_active) return false;
        }
        
        if (filter.is_superuser) |is_superuser| {
            if (user.is_superuser != is_superuser) return false;
        }
        
        if (filter.has_mfa) |has_mfa| {
            if (user.mfa_enabled != has_mfa) return false;
        }
        
        if (filter.role_name) |role_name| {
            const user_roles = self.security_manager.rbac.user_roles.get(user.id) orelse
                return false;
            
            var has_role = false;
            for (user_roles.items) |role_id| {
                if (self.security_manager.roles.get(role_id)) |role| {
                    if (std.mem.eql(u8, role.name, role_name)) {
                        has_role = true;
                        break;
                    }
                }
            }
            if (!has_role) return false;
        }
        
        if (filter.created_after) |after| {
            if (user.created_at < after) return false;
        }
        
        if (filter.created_before) |before| {
            if (user.created_at > before) return false;
        }
        
        return true;
    }
    
    // Role Management
    pub const CreateRoleRequest = struct {
        name: []const u8,
        description: []const u8,
        permissions: ?[]const []const u8 = null,
        parent_role: ?[]const u8 = null,
        priority: ?u32 = null,
    };
    
    pub fn createRole(self: *Self, request: CreateRoleRequest) !auth.RoleId {
        const role = try self.security_manager.createRole(
            request.name,
            request.description,
        );
        
        // Set parent role if specified
        if (request.parent_role) |parent_name| {
            var it = self.security_manager.roles.iterator();
            while (it.next()) |entry| {
                if (std.mem.eql(u8, entry.value_ptr.name, parent_name)) {
                    role.parent_role = entry.key_ptr.*;
                    break;
                }
            }
        }
        
        // Set priority if specified
        if (request.priority) |priority| {
            role.priority = priority;
        }
        
        // Grant permissions if specified
        if (request.permissions) |permissions| {
            for (permissions) |perm_name| {
                var it = self.security_manager.permissions.iterator();
                while (it.next()) |entry| {
                    if (std.mem.eql(u8, entry.value_ptr.name, perm_name)) {
                        try self.security_manager.grantPermission(role.id, entry.key_ptr.*);
                        break;
                    }
                }
            }
        }
        
        // Persist to storage
        try self.persistRole(role.*);
        
        return role.id;
    }
    
    pub fn updateRole(
        self: *Self,
        role_id: auth.RoleId,
        description: ?[]const u8,
        priority: ?u32,
    ) !void {
        const role = self.security_manager.roles.getPtr(role_id) orelse
            return error.RoleNotFound;
        
        if (description) |desc| {
            role.description = try self.allocator.dupe(u8, desc);
        }
        
        if (priority) |pri| {
            role.priority = pri;
        }
        
        try self.persistRole(role.*);
    }
    
    pub fn deleteRole(self: *Self, role_id: auth.RoleId) !void {
        const role = self.security_manager.roles.get(role_id) orelse
            return error.RoleNotFound;
        
        if (role.is_system) {
            return error.CannotDeleteSystemRole;
        }
        
        // Remove role from all users
        var it = self.security_manager.rbac.user_roles.iterator();
        while (it.next()) |entry| {
            var i: usize = 0;
            while (i < entry.value_ptr.items.len) {
                if (entry.value_ptr.items[i] == role_id) {
                    _ = entry.value_ptr.swapRemove(i);
                } else {
                    i += 1;
                }
            }
        }
        
        // Remove from storage
        try self.removeRoleFromStorage(role_id);
        
        // Remove from memory
        _ = self.security_manager.roles.remove(role_id);
    }
    
    // Permission Management
    pub const CreatePermissionRequest = struct {
        name: []const u8,
        resource: []const u8,
        action: auth.Action,
        conditions: ?[]const u8 = null,
    };
    
    pub fn createPermission(self: *Self, request: CreatePermissionRequest) !auth.PermissionId {
        const permission = try self.security_manager.createPermission(
            request.name,
            request.resource,
            request.action,
        );
        
        if (request.conditions) |conditions| {
            permission.conditions = try self.allocator.dupe(u8, conditions);
        }
        
        try self.persistPermission(permission.*);
        
        return permission.id;
    }
    
    // RLS Policy Management
    pub const CreatePolicyRequest = struct {
        name: []const u8,
        description: []const u8,
        graph: []const u8,
        table: []const u8,
        operation: rls.RLSEngine.Operation,
        permissive: bool = true,
        roles: []const []const u8,
        using_clause: ?[]const u8 = null,
        check_clause: ?[]const u8 = null,
        temporal: ?rls.RLSEngine.TemporalConstraint = null,
        data_classification: ?rls.RLSEngine.DataClassification = null,
        audit_level: rls.RLSEngine.AuditLevel = .denials,
    };
    
    pub fn createPolicy(self: *Self, request: CreatePolicyRequest) !u64 {
        // Convert role names to IDs
        var role_ids = std.ArrayList(auth.RoleId).init(self.allocator);
        for (request.roles) |role_name| {
            var it = self.security_manager.roles.iterator();
            while (it.next()) |entry| {
                if (std.mem.eql(u8, entry.value_ptr.name, role_name)) {
                    try role_ids.append(entry.key_ptr.*);
                    break;
                }
            }
        }
        
        const policy_id = @as(u64, @intCast(std.time.milliTimestamp()));
        
        const policy = rls.RLSEngine.Policy{
            .id = policy_id,
            .name = try self.allocator.dupe(u8, request.name),
            .description = try self.allocator.dupe(u8, request.description),
            .graph = try self.allocator.dupe(u8, request.graph),
            .table = try self.allocator.dupe(u8, request.table),
            .operation = request.operation,
            .permissive = request.permissive,
            .roles = try role_ids.toOwnedSlice(),
            .using_expr = if (request.using_clause) |clause| rls.RLSEngine.Expression{
                .raw = try self.allocator.dupe(u8, clause),
                .parsed = null,
                .compiled = null,
                .parameters = &[_]rls.RLSEngine.Expression.Parameter{},
            } else null,
            .check_expr = if (request.check_clause) |clause| rls.RLSEngine.Expression{
                .raw = try self.allocator.dupe(u8, clause),
                .parsed = null,
                .compiled = null,
                .parameters = &[_]rls.RLSEngine.Expression.Parameter{},
            } else null,
            .enabled = true,
            .created_at = std.time.milliTimestamp(),
            .updated_at = std.time.milliTimestamp(),
            .created_by = 0, // System user
            .temporal = request.temporal,
            .data_classification = request.data_classification,
            .audit_level = request.audit_level,
        };
        
        try self.rls_engine.createPolicy(policy);
        try self.persistPolicy(policy);
        
        return policy_id;
    }
    
    pub fn updatePolicy(
        self: *Self,
        policy_id: u64,
        enabled: ?bool,
        using_clause: ?[]const u8,
        check_clause: ?[]const u8,
    ) !void {
        // Find the policy
        var found_policy: ?rls.RLSEngine.Policy = null;
        var policy_key: ?rls.RLSEngine.PolicyKey = null;
        
        var it = self.rls_engine.policies.iterator();
        while (it.next()) |entry| {
            for (entry.value_ptr.items) |policy| {
                if (policy.id == policy_id) {
                    found_policy = policy;
                    policy_key = entry.key_ptr.*;
                    break;
                }
            }
        }
        
        var policy = found_policy orelse return error.PolicyNotFound;
        
        // Update fields
        if (enabled) |e| {
            policy.enabled = e;
        }
        
        if (using_clause) |clause| {
            policy.using_expr = rls.RLSEngine.Expression{
                .raw = try self.allocator.dupe(u8, clause),
                .parsed = null,
                .compiled = null,
                .parameters = &[_]rls.RLSEngine.Expression.Parameter{},
            };
        }
        
        if (check_clause) |clause| {
            policy.check_expr = rls.RLSEngine.Expression{
                .raw = try self.allocator.dupe(u8, clause),
                .parsed = null,
                .compiled = null,
                .parameters = &[_]rls.RLSEngine.Expression.Parameter{},
            };
        }
        
        try self.rls_engine.updatePolicy(policy_id, policy);
        try self.persistPolicy(policy);
    }
    
    pub fn deletePolicy(self: *Self, policy_id: u64) !void {
        try self.rls_engine.deletePolicy(policy_id);
        try self.removePolicyFromStorage(policy_id);
    }
    
    // Storage persistence
    fn persistUser(self: *Self, user: auth.User) !void {
        _ = self;
        _ = user;
        // TODO: Implement actual persistence to storage backend
    }
    
    fn removeUserFromStorage(self: *Self, user_id: auth.UserId) !void {
        _ = self;
        _ = user_id;
        // TODO: Implement removal from storage backend
    }
    
    fn persistRole(self: *Self, role: auth.Role) !void {
        _ = self;
        _ = role;
        // TODO: Implement actual persistence to storage backend
    }
    
    fn removeRoleFromStorage(self: *Self, role_id: auth.RoleId) !void {
        _ = self;
        _ = role_id;
        // TODO: Implement removal from storage backend
    }
    
    fn persistPermission(self: *Self, permission: auth.Permission) !void {
        _ = self;
        _ = permission;
        // TODO: Implement actual persistence to storage backend
    }
    
    fn persistPolicy(self: *Self, policy: rls.RLSEngine.Policy) !void {
        _ = self;
        _ = policy;
        // TODO: Implement actual persistence to storage backend
    }
    
    fn removePolicyFromStorage(self: *Self, policy_id: u64) !void {
        _ = self;
        _ = policy_id;
        // TODO: Implement removal from storage backend
    }
    
    fn generateMFASecret(self: *Self) ![]const u8 {
        var secret: [32]u8 = undefined;
        std.crypto.random.bytes(&secret);
        return try std.base64.standard.Encoder.encode(self.allocator, &secret);
    }
};

// CLI Commands
pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();
    
    const args = try std.process.argsAlloc(allocator);
    defer std.process.argsFree(allocator, args);
    
    if (args.len < 2) {
        try printHelp();
        return;
    }
    
    const command = args[1];
    
    if (std.mem.eql(u8, command, "user")) {
        if (args.len < 3) {
            try printUserHelp();
            return;
        }
        try handleUserCommand(allocator, args[2..]);
    } else if (std.mem.eql(u8, command, "role")) {
        if (args.len < 3) {
            try printRoleHelp();
            return;
        }
        try handleRoleCommand(allocator, args[2..]);
    } else if (std.mem.eql(u8, command, "policy")) {
        if (args.len < 3) {
            try printPolicyHelp();
            return;
        }
        try handlePolicyCommand(allocator, args[2..]);
    } else {
        try printHelp();
    }
}

fn printHelp() !void {
    const stdout = std.io.getStdOut().writer();
    try stdout.print(
        \\Usage: geode-auth <command> [options]
        \\
        \\Commands:
        \\  user     Manage users
        \\  role     Manage roles
        \\  policy   Manage RLS policies
        \\
        \\Use 'geode-auth <command> --help' for more information about a command.
        \\
    , .{});
}

fn printUserHelp() !void {
    const stdout = std.io.getStdOut().writer();
    try stdout.print(
        \\Usage: geode-auth user <subcommand> [options]
        \\
        \\Subcommands:
        \\  create   Create a new user
        \\  update   Update an existing user
        \\  delete   Delete a user
        \\  list     List all users
        \\  show     Show user details
        \\  grant    Grant role to user
        \\  revoke   Revoke role from user
        \\
    , .{});
}

fn printRoleHelp() !void {
    const stdout = std.io.getStdOut().writer();
    try stdout.print(
        \\Usage: geode-auth role <subcommand> [options]
        \\
        \\Subcommands:
        \\  create   Create a new role
        \\  update   Update an existing role
        \\  delete   Delete a role
        \\  list     List all roles
        \\  grant    Grant permission to role
        \\  revoke   Revoke permission from role
        \\
    , .{});
}

fn printPolicyHelp() !void {
    const stdout = std.io.getStdOut().writer();
    try stdout.print(
        \\Usage: geode-auth policy <subcommand> [options]
        \\
        \\Subcommands:
        \\  create   Create a new RLS policy
        \\  update   Update an existing policy
        \\  delete   Delete a policy
        \\  list     List all policies
        \\  enable   Enable a policy
        \\  disable  Disable a policy
        \\
    , .{});
}

fn handleUserCommand(allocator: Allocator, args: [][]const u8) !void {
    _ = allocator;
    _ = args;
    // TODO: Implement user command handling
}

fn handleRoleCommand(allocator: Allocator, args: [][]const u8) !void {
    _ = allocator;
    _ = args;
    // TODO: Implement role command handling
}

fn handlePolicyCommand(allocator: Allocator, args: [][]const u8) !void {
    _ = allocator;
    _ = args;
    // TODO: Implement policy command handling
}